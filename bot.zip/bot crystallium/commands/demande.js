const {
  SlashCommandBuilder
} = require('@discordjs/builders');
const { MessageActionRow, MessageButton, MessageEmbed, Message} = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder()
    .setName('demande')
    .setDescription('envoyer un message au staff.')
    .addStringOption(option =>
        option.setName('raison')
        .setDescription('raison du message')
        .setRequired(true))
        .addStringOption(option =>
          option.setName('url')
          .setDescription('url de l`arrière plan')
          .setRequired(false)),

        async execute(interaction, client) {
          const r = (interaction.options.getString('raison'));
          const executer = client.guilds.cache.get(interaction.guildId).members.cache.get(interaction.user.id);
          if (!executer.permissions.has(client.discord.Permissions.FLAGS.KICK_MEMBERS)) return interaction.reply({
            content: 'tu n`a pas la perm de utiliser cette commande',
            ephemeral: true
          });
          
          const row = new MessageActionRow()
              .addComponents(
                  new MessageButton()
                      .setCustomId("Peut")
                      .setLabel('Je peut')
                      .setEmoji("<​:check_yes:1017179810268721172>")
                      .setStyle('SUCCESS'),
                      
  
                      new MessageButton()
                      .setCustomId('peutpas')
                      .setLabel('Je ne peut pas')
                      .setStyle('DANGER'),

                      new MessageButton()
                      .setCustomId('saispas')
                      .setLabel('Je ne sais pas')
                      .setStyle('DANGER'),
                      
              );
              
              const embed = new MessageEmbed()
              .setColor('#0099ff')
              .setTitle("Demande du staff par " + "<@!" + interaction.user.id + ">" + "\n\nRaison : " + r)
              .setImage((interaction.options.getString('url')) || "https://cdn.vox-cdn.com/thumbor/9vIVNrWfcDjaN37YDZNyBldq7vE=/0x0:2040x1360/620x413/filters:focal(857x517:1183x843):format(webp)/cdn.vox-cdn.com/uploads/chorus_image/image/70550646/acastro_200318_1777_discord_0002.0.0.jpg")
              .setDescription('Clique si dessous pour dire ta disponibilité');
  
              if (interaction.customId == "Peut") {
                Message.channel.send("test")
              }

      }
      
    }
    
  
   
