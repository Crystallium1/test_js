const { MessageEmbed } = require('discord.js');

module.exports = {
 name: 'emojis',
 description: "Gets a guild's emojis",

 async run(client, message, args) {
  const charactersPerMessage = 2000;
  const emojis = message.guild.emojis.cache.map((e) => {
   return `${e} **-** \`:${e.name}:\``;
  });
  const numberOfMessages = Math.ceil(emojis.length / charactersPerMessage);
  const embed = new MessageEmbed().setTitle(`Emoji List`);
  for (i = 0; i < numberOfMessages; i++) {
   message.channel.send(
    embed.setDescription(
     emojis.slice(i * charactersPerMessage, (i + 1) * charactersPerMessage)
    )
   );
  }
 },
};